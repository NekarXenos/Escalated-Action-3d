// sceneSetup.js
import * as THREE from 'three';
import { SETTINGS } from './settings.js'; // Assuming settings.js is in the same directory

// Core Three.js components
let scene;
let camera;
let renderer;
let clock;

// Player-specific camera properties (can be adjusted by player controls later)
let playerHeight = 1.7; // Initial camera height offset from player's feet

/**
 * Initializes the core Three.js scene, camera, renderer, and basic lighting.
 * @param {HTMLCanvasElement} canvas - The canvas element to render to.
 * @returns {object} An object containing the initialized scene, camera, renderer, and clock.
 */
function initializeScene(canvas) {
    // Clock for timing
    clock = new THREE.Clock();

    // Scene
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x010309); // Dark blue for a moonlit night
    scene.fog = new THREE.Fog(0x010309, 10, 100); // Fog to match the night theme

    // Camera
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    // Initial camera position will be set after world/elevators are generated,
    // but we can give it a temporary position.
    camera.position.set(SETTINGS.corridorWidth / 2, playerHeight, 5); // Default starting position

    // Renderer
    renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true;
    // renderer.outputColorSpace = THREE.SRGBColorSpace; // Optional: for more accurate colors if using post-processing or specific textures

    // Basic Lighting
    const ambientLight = new THREE.AmbientLight(0x015599, 0.1); // Dim bluish ambient light
    scene.add(ambientLight);

    const moonlight = new THREE.DirectionalLight(0x015599, 0.3); // Soft bluish moonlight
    moonlight.position.set(-10, 20, -10); // Position the moonlight
    moonlight.castShadow = true;
    // Configure shadow properties for moonlight (optional, but good for quality)
    moonlight.shadow.mapSize.width = 1024; // default
    moonlight.shadow.mapSize.height = 1024; // default
    moonlight.shadow.camera.near = 0.5; // default
    moonlight.shadow.camera.far = 50; // default
    moonlight.shadow.bias = -0.001; // Helps prevent shadow acne

    scene.add(moonlight);

    // Handle window resizing
    window.addEventListener('resize', onWindowResize);

    return { scene, camera, renderer, clock, playerHeight };
}

/**
 * Handles window resize events to update camera aspect ratio and renderer size.
 */
function onWindowResize() {
    if (camera && renderer) {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    }
}

export { initializeScene, scene, camera, renderer, clock, playerHeight, onWindowResize };
