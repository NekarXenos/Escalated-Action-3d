// elevator.js
import * as THREE from 'three';
import { SETTINGS } from './settings.js';
// Assuming scene will be passed to createElevator, or imported if it becomes a global/singleton
// For player interactions, we might need to import functions from playerControls.js
import { getControlsObject, getPlayerHeight, getPlayerState, setPlayerState, getPlayerVelocity, setPlayerOnGround } from './playerControls.js'; // Assuming these getters/setters exist
// Placeholder for UI functions, these would ideally be in a ui.js module
// import { displayCrushBanner, respawnPlayer } from './ui.js';
// Placeholder for game state functions
// import { applyDamageToPlayer } from './gameLogic.js';


// --- Elevator State ---
const elevators = []; // Array to store all elevator objects
let activeElevator = null; // The elevator currently being controlled or closest to the player

// This will be used by createElevator, passed from worldGenerator
// let worldObjectsRef; // Reference to the main worldObjects array for collision

/**
 * Creates a single elevator instance with its platform, internal roof, poles, shaft structures, chain, and piston.
 * @param {object} config - Configuration object for the elevator.
 * @param {string} config.id - Unique ID for the elevator.
 * @param {number} config.x - Center X position of the elevator shaft.
 * @param {number} config.z - Center Z position of the elevator shaft.
 * @param {number} config.shaftWidth - Width of the elevator shaft.
 * @param {number} config.shaftDepth - Depth of the elevator shaft.
 * @param {number} config.minFloorIndex - The lowest floor index this elevator serves.
 * @param {number} config.maxFloorIndex - The highest floor index this elevator serves.
 * @param {number} config.startFloorIndex - The initial floor index where the elevator starts.
 * @param {THREE.Material} config.platformMaterial - Material for the elevator platform and internal roof.
 * @param {THREE.Material} config.shaftMaterial - Material for the shaft ceiling and pit.
 * @param {THREE.Scene} config.scene - The main Three.js scene to add elevator parts to.
 * @param {Array<THREE.Mesh>} config.worldObjectsArr - Reference to the global array of collidable world objects.
 * @returns {object} The created elevator object.
 */
function createElevator(config) {
    const floorDepth = SETTINGS.floorHeight - SETTINGS.wallHeight; // Calculate based on SETTINGS

    const elevatorObj = {
        id: config.id,
        platform: null,
        roof: null, // elevator's own internal roof
        chain: null,
        shaftCeiling: null, // Topmost ceiling of the elevator shaft
        shaftPit: null,     // Bottommost base of the elevator shaft
        poles: [],
        minFloorIndex: config.minFloorIndex,
        maxFloorIndex: config.maxFloorIndex,
        currentY: (config.startFloorIndex * SETTINGS.floorHeight) - 0.1, // Platform center Y
        targetY: (config.startFloorIndex * SETTINGS.floorHeight) - 0.1,
        isMoving: false,
        direction: 0,
        currentFloorIndexVal: config.startFloorIndex,
        config: config // Store original config for reference
    };

    // 1. Elevator Platform
    const platformGeo = new THREE.BoxGeometry(config.shaftWidth - 0.2, 0.2, config.shaftDepth - 0.2);
    elevatorObj.platform = new THREE.Mesh(platformGeo, config.platformMaterial);
    elevatorObj.platform.name = `ElevatorPlatform_${config.id}`;
    elevatorObj.platform.position.set(config.x, elevatorObj.currentY, config.z);
    elevatorObj.platform.castShadow = true;
    elevatorObj.platform.receiveShadow = true;
    config.scene.add(elevatorObj.platform);
    config.worldObjectsArr.push(elevatorObj.platform);
    elevatorObj.platform.userData.elevatorId = config.id;
    if (!elevatorObj.platform.geometry.boundingBox) {
        elevatorObj.platform.geometry.computeBoundingBox();
    }


    // 2. Elevator's Own Internal Roof
    const elevatorInternalRoofThickness = 0.2;
    const internalRoofGeo = new THREE.BoxGeometry(config.shaftWidth - 0.2, elevatorInternalRoofThickness, config.shaftDepth - 0.2);
    elevatorObj.roof = new THREE.Mesh(internalRoofGeo, config.platformMaterial);
    elevatorObj.roof.name = `ElevatorInternalRoof_${config.id}`;
    elevatorObj.roof.position.set(config.x, elevatorObj.currentY + SETTINGS.wallHeight, config.z);
    elevatorObj.roof.castShadow = true;
    elevatorObj.roof.receiveShadow = true;
    config.scene.add(elevatorObj.roof);
    config.worldObjectsArr.push(elevatorObj.roof);
    if (!elevatorObj.roof.geometry.boundingBox) {
        elevatorObj.roof.geometry.computeBoundingBox();
    }
    elevatorObj.roof.userData.elevatorId = config.id;


    // Add a light inside the elevator, attached to its internal roof
    const elevatorLight = new THREE.PointLight(0xffffff, 0.8, 4); // color, intensity, distance
    elevatorLight.position.set(0, -elevatorInternalRoofThickness / 2 - 0.1, 0);
    elevatorObj.roof.add(elevatorLight); // Light is a child of the roof

    // 3. Vertical Poles inside elevator (children of the platform)
    const poleDimension = 0.1;
    const poleHeight = SETTINGS.wallHeight;
    const poleGeo = new THREE.BoxGeometry(poleDimension, poleHeight, poleDimension);
    const platformInnerWidth = config.shaftWidth - 0.2;
    const platformInnerDepth = config.shaftDepth - 0.2;

    const polePositions = [
        { x: -platformInnerWidth / 2 + poleDimension / 2, z: -platformInnerDepth / 2 + poleDimension / 2 },
        { x:  platformInnerWidth / 2 - poleDimension / 2, z: -platformInnerDepth / 2 + poleDimension / 2 },
        { x: -platformInnerWidth / 2 + poleDimension / 2, z:  platformInnerDepth / 2 - poleDimension / 2 },
        { x:  platformInnerWidth / 2 - poleDimension / 2, z:  platformInnerDepth / 2 - poleDimension / 2 }
    ];
    polePositions.forEach((pos, index) => {
        const pole = new THREE.Mesh(poleGeo, config.platformMaterial.clone()); // Clone material if poles might have different properties later
        pole.name = `ElevatorPole_${config.id}_${index}`;
        pole.position.set(pos.x, 0.1 + poleHeight / 2, pos.z); // Y relative to platform center
        pole.castShadow = true; pole.receiveShadow = true;
        pole.userData.elevatorId = config.id;
        elevatorObj.platform.add(pole); // Pole is a child of the platform
        elevatorObj.poles.push(pole);
        // Bounding box for poles might not be strictly necessary for worldObjects if platform collision is sufficient
    });

    // 4. Elevator Shaft Ceiling (Topmost structure of the shaft)
    const shaftCeilingY = (config.maxFloorIndex + 1) * SETTINGS.floorHeight;
    const shaftCeilingGeo = new THREE.BoxGeometry(config.shaftWidth, floorDepth - 0.02, config.shaftDepth);
    elevatorObj.shaftCeiling = new THREE.Mesh(shaftCeilingGeo, config.shaftMaterial);
    elevatorObj.shaftCeiling.name = `ElevatorShaftCeiling_${config.id}`;
    elevatorObj.shaftCeiling.position.set(config.x, shaftCeilingY - floorDepth / 2, config.z);
    elevatorObj.shaftCeiling.castShadow = true; elevatorObj.shaftCeiling.receiveShadow = true;
    config.scene.add(elevatorObj.shaftCeiling);
    config.worldObjectsArr.push(elevatorObj.shaftCeiling);
    if (!elevatorObj.shaftCeiling.geometry.boundingBox) {
        elevatorObj.shaftCeiling.geometry.computeBoundingBox();
    }


    // 5. Elevator Shaft Pit Base (Bottommost structure of the shaft)
    const pitThickness = SETTINGS.floorHeight;
    const pitTopSurfaceY = (config.minFloorIndex * SETTINGS.floorHeight) - floorDepth;
    const pitCenterY = pitTopSurfaceY - pitThickness / 2;
    const pitGeo = new THREE.BoxGeometry(config.shaftWidth, pitThickness, config.shaftDepth);
    elevatorObj.shaftPit = new THREE.Mesh(pitGeo, config.shaftMaterial);
    elevatorObj.shaftPit.name = `ElevatorShaftPit_${config.id}`;
    elevatorObj.shaftPit.position.set(config.x, pitCenterY, config.z);
    elevatorObj.shaftPit.receiveShadow = true;
    config.scene.add(elevatorObj.shaftPit);
    config.worldObjectsArr.push(elevatorObj.shaftPit);
    if (!elevatorObj.shaftPit.geometry.boundingBox) {
        elevatorObj.shaftPit.geometry.computeBoundingBox();
    }

    // 6. Dynamic Chain (child of the platform)
    const chain = createDynamicChainMesh(elevatorObj, config.platformMaterial);
    elevatorObj.chain = chain;
    chain.userData.elevatorId = config.id;
    elevatorObj.platform.add(chain); // Chain is a child of the platform

    // 7. Bottom Piston Shaft (child of the platform)
    const piston = createElevatorPistonMesh(elevatorObj, config.platformMaterial);
    piston.userData.elevatorId = config.id;
    elevatorObj.platform.add(piston); // Piston is a child of the platform
    // config.worldObjectsArr.push(piston); // Add piston to worldObjects if it needs separate collision

    elevators.push(elevatorObj);
    if (!activeElevator) {
        activeElevator = elevatorObj;
    }
    return elevatorObj;
}

/**
 * Creates the mesh for the elevator's bottom piston.
 * @param {object} elevatorObj - The elevator object this piston belongs to.
 * @param {THREE.Material} material - The material for the piston.
 * @returns {THREE.Mesh} The created piston mesh.
 */
function createElevatorPistonMesh(elevatorObj, material) {
    const bottomShaftThickness = 0.2;
    const totalTravel = (elevatorObj.maxFloorIndex - elevatorObj.minFloorIndex) * SETTINGS.floorHeight;
    const bottomShaftActualHeight = totalTravel + SETTINGS.floorHeight;

    const bottomShaftGeo = new THREE.BoxGeometry(bottomShaftThickness, bottomShaftActualHeight, bottomShaftThickness);
    const bottomShaft = new THREE.Mesh(bottomShaftGeo, material);
    bottomShaft.name = `ElevatorBottomPistonShaft_${elevatorObj.id}`;
    bottomShaft.position.set(0, -0.1 - (bottomShaftActualHeight / 2), 0); // Relative to platform
    bottomShaft.castShadow = true;
    bottomShaft.receiveShadow = true;
    if (!bottomShaft.geometry.boundingBox) {
        bottomShaft.geometry.computeBoundingBox();
    }
    return bottomShaft;
}

/**
 * Creates the mesh for the elevator's dynamic chain.
 * @param {object} elevatorObj - The elevator object this chain belongs to.
 * @param {THREE.Material} material - The material for the chain.
 * @returns {THREE.Mesh} The created chain mesh.
 */
function createDynamicChainMesh(elevatorObj, material) {
    const chainThickness = 0.1;
    const internalRoofThickness = elevatorObj.roof.geometry.parameters.height;

    const internalRoofTopLocalY = (0.1 + SETTINGS.wallHeight - internalRoofThickness / 2) + internalRoofThickness;
    const minPlatformY = (elevatorObj.minFloorIndex * SETTINGS.floorHeight) - 0.1;
    const minInternalRoofTopWorldY = minPlatformY + internalRoofTopLocalY;
    const shaftCeilingBottomWorldY = elevatorObj.shaftCeiling.position.y - elevatorObj.shaftCeiling.geometry.parameters.height / 2;
    const initialGeomHeight = Math.max(0.01, shaftCeilingBottomWorldY - minInternalRoofTopWorldY);

    const chainGeometry = new THREE.BoxGeometry(chainThickness, initialGeomHeight, chainThickness);
    const chainMesh = new THREE.Mesh(chainGeometry, material);
    chainMesh.name = `ElevatorChain_${elevatorObj.id}`;
    chainMesh.position.set(0, internalRoofTopLocalY + initialGeomHeight / 2, 0); // Relative to platform
    chainMesh.castShadow = true;
    chainMesh.receiveShadow = true;
    chainMesh.userData.initialGeomHeight = initialGeomHeight;
    return chainMesh;
}

/**
 * Updates the visual length of an elevator's chain based on its current position.
 * @param {object} elevatorInstance - The elevator instance whose chain needs updating.
 */
function updateChainLength(elevatorInstance) {
    const chain = elevatorInstance.chain;
    const internalRoof = elevatorInstance.roof;
    const shaftCeiling = elevatorInstance.shaftCeiling;

    if (chain && internalRoof && shaftCeiling && chain.userData.initialGeomHeight) {
        const initialGeomHeight = chain.userData.initialGeomHeight;
        const internalRoofThickness = internalRoof.geometry.parameters.height;

        const internalRoofTopWorldY = internalRoof.position.y + internalRoofThickness / 2;
        const shaftCeilingBottomWorldY = shaftCeiling.position.y - shaftCeiling.geometry.parameters.height / 2;
        const currentVisibleChainLength = Math.max(0.01, shaftCeilingBottomWorldY - internalRoofTopWorldY);

        chain.scale.y = currentVisibleChainLength / initialGeomHeight;

        const internalRoofTopLocalY = (0.1 + SETTINGS.wallHeight - internalRoofThickness / 2) + internalRoofThickness;
        chain.position.y = internalRoofTopLocalY + currentVisibleChainLength / 2;
    }
}

/**
 * Finds the elevator closest to the player.
 * @returns {object|null} The closest elevator object or null if no elevators exist.
 */
function getClosestElevator() {
    if (elevators.length === 0) return null;
    if (elevators.length === 1) return elevators[0];

    const playerControlObject = getControlsObject();
    if (!playerControlObject) return elevators[0]; // Fallback if player controls not ready

    const playerPos = playerControlObject.position;
    let closestDistanceSq = Infinity;
    let closestElev = elevators[0];

    for (const elev of elevators) {
        const distanceSq = playerPos.distanceToSquared(elev.platform.position);
        if (distanceSq < closestDistanceSq) {
            closestDistanceSq = distanceSq;
            closestElev = elev;
        }
    }
    return closestElev;
}

/**
 * Calls the closest elevator to move up or down by one floor.
 * @param {number} direction - +1 to move up, -1 to move down.
 */
function callElevator(direction) {
    const currentActiveElevator = getClosestElevator();
    if (!currentActiveElevator) return;
    activeElevator = currentActiveElevator; // Update global active elevator

    let targetFloor = activeElevator.currentFloorIndexVal + direction;
    targetFloor = Math.max(activeElevator.minFloorIndex, Math.min(activeElevator.maxFloorIndex, targetFloor));
    const newTargetY = (targetFloor * SETTINGS.floorHeight) - 0.1;

    if (newTargetY !== activeElevator.targetY || !activeElevator.isMoving) {
        activeElevator.targetY = newTargetY;
        activeElevator.direction = Math.sign(activeElevator.targetY - activeElevator.platform.position.y);
        if (activeElevator.platform.position.y.toFixed(2) !== newTargetY.toFixed(2)) {
             activeElevator.isMoving = true;
        }
        console.log(`Elevator ${activeElevator.id} called to floor ${targetFloor}. Moving ${activeElevator.direction > 0 ? 'UP' : (activeElevator.direction < 0 ? 'DOWN' : 'STATIONARY')}.`);
    }
}

/**
 * Calls a specific elevator to a specific floor index.
 * @param {object} elevatorInstance - The elevator instance to call.
 * @param {number} targetFloorIndex - The floor index to call the elevator to.
 */
function callSpecificElevatorToFloor(elevatorInstance, targetFloorIndex) {
    if (!elevatorInstance) return;

    const effectiveTargetFloor = Math.max(elevatorInstance.minFloorIndex, Math.min(elevatorInstance.maxFloorIndex, targetFloorIndex));
    const newTargetY = (effectiveTargetFloor * SETTINGS.floorHeight) - 0.1;

    if (newTargetY !== elevatorInstance.targetY || !elevatorInstance.isMoving) {
        elevatorInstance.targetY = newTargetY;
        elevatorInstance.direction = Math.sign(elevatorInstance.targetY - elevatorInstance.platform.position.y);
        if (elevatorInstance.platform.position.y.toFixed(2) !== newTargetY.toFixed(2)) {
            elevatorInstance.isMoving = true;
        }
        console.log(`Elevator ${elevatorInstance.id} specifically called to floor ${effectiveTargetFloor}.`);
        activeElevator = elevatorInstance; // Make this the active elevator
    }
}

/**
 * Updates the state and position of all elevators.
 * @param {number} deltaTime - The time elapsed since the last frame.
 * @param {Function} displayCrushBannerFn - Function to display the crush banner.
 * @param {Function} respawnPlayerFn - Function to respawn the player.
 * @param {Function} applyDamageFn - Function to apply damage to the player.
 * @param {object} gameStatus - Object containing game status like isPlayerRespawning.
 */
function updateElevators(deltaTime, displayCrushBannerFn, respawnPlayerFn, applyDamageFn, gameStatus) {
    const playerControlObject = getControlsObject();
    const playerHeight = getPlayerHeight();

    elevators.forEach(elev => {
        if (!elev.isMoving) return;

        const targetY = elev.targetY;
        const currentPlatformY = elev.platform.position.y;
        const moveAmount = SETTINGS.elevatorSpeed * deltaTime * elev.direction;
        let nextPlatformY = currentPlatformY + moveAmount;
        let arrived = false;

        if (elev.direction > 0 && nextPlatformY >= targetY) {
            nextPlatformY = targetY; arrived = true;
        } else if (elev.direction < 0 && nextPlatformY <= targetY) {
            nextPlatformY = targetY; arrived = true;
        }

        elev.platform.position.y = nextPlatformY;
        elev.currentY = nextPlatformY;
        if (elev.roof) {
            elev.roof.position.y = nextPlatformY + SETTINGS.wallHeight;
            updateChainLength(elev);
        }

        // Update matrix world for accurate collision and player position checks
        elev.platform.updateMatrixWorld(true);
        if (elev.roof) elev.roof.updateMatrixWorld(true);


        if (playerControlObject) {
            handlePlayerCrush(elev, currentPlatformY, nextPlatformY, displayCrushBannerFn, applyDamageFn, gameStatus);

            const playerPos = playerControlObject.position;
            const playerIsOnThisPlatform =
                Math.abs(playerPos.x - elev.platform.position.x) < (elev.config.shaftWidth / 2 - 0.1) &&
                Math.abs(playerPos.z - elev.platform.position.z) < (elev.config.shaftDepth / 2 - 0.1) &&
                playerPos.y >= elev.platform.position.y + 0.1 && // Player feet on or above platform top
                playerPos.y <= elev.platform.position.y + 0.1 + playerHeight + 0.2; // Player head below elevator ceiling clearance


            const playerIsOnThisInternalRoof = elev.roof &&
                Math.abs(playerPos.x - elev.roof.position.x) < (elev.config.shaftWidth / 2 - 0.1) &&
                Math.abs(playerPos.z - elev.roof.position.z) < (elev.config.shaftDepth / 2 - 0.1) &&
                playerPos.y >= elev.roof.position.y + elev.roof.geometry.parameters.height / 2 &&
                playerPos.y <= elev.roof.position.y + elev.roof.geometry.parameters.height / 2 + playerHeight + 0.2;


            if (playerIsOnThisPlatform) {
                playerPos.y = elev.platform.position.y + 0.1 + playerHeight; // Adjust Y based on platform top
                setPlayerOnGround(true);
                getPlayerVelocity().y = 0; // Stop vertical velocity if on platform
            } else if (playerIsOnThisInternalRoof) {
                playerPos.y = elev.roof.position.y + (elev.roof.geometry.parameters.height / 2) + playerHeight;
                setPlayerOnGround(true);
                getPlayerVelocity().y = 0;
            }
        }

        if (arrived) {
            elev.isMoving = false;
            elev.currentFloorIndexVal = Math.round((targetY + 0.1) / SETTINGS.floorHeight);
            console.log(`Elevator ${elev.id} arrived at floor ${elev.currentFloorIndexVal}`);

            if (playerControlObject && (playerIsOnThisPlatform /* from closure, might be stale */)) {
                 // Check again with new platform position
                const playerPos = playerControlObject.position;
                const stillOnPlatform = Math.abs(playerPos.x - elev.platform.position.x) < (elev.config.shaftWidth / 2 - 0.1) &&
                                    Math.abs(playerPos.z - elev.platform.position.z) < (elev.config.shaftDepth / 2 - 0.1) &&
                                    Math.abs(playerPos.y - (elev.platform.position.y + 0.1 + playerHeight)) < 0.3;
                if (stillOnPlatform) {
                    getPlayerVelocity().y = 2.0; // Slight jump effect
                    setPlayerOnGround(false);
                }
            }

            if (gameStatus.isPlayerRespawning && elev === activeElevator) {
                if (typeof respawnPlayerFn === 'function') respawnPlayerFn();
                else console.warn("respawnPlayer function not provided to updateElevators");
            }
        }
    });
}

/**
 * Handles potential crushing of the player by an elevator.
 * @param {object} elevatorInstance - The elevator instance.
 * @param {number} currentPlatformY - The platform's Y position before the current move.
 * @param {number} nextPlatformY - The platform's Y position after the current move.
 * @param {Function} displayCrushBannerFn - Function to display the crush banner.
 * @param {Function} applyDamageFn - Function to apply damage to the player.
 * @param {object} gameStatusRef - Mutable reference to game status object (e.g., { isPlayerRespawning }).
 */
function handlePlayerCrush(elevatorInstance, currentPlatformY, nextPlatformY, displayCrushBannerFn, applyDamageFn, gameStatusRef) {
    const playerControlObject = getControlsObject();
    if (!playerControlObject) return;

    const playerPos = playerControlObject.position;
    const playerCurrentHeight = getPlayerHeight(); // Actual collision height
    let playerCurrentState = getPlayerState();

    const platform = elevatorInstance.platform;
    const internalRoof = elevatorInstance.roof;
    const shaftCeiling = elevatorInstance.shaftCeiling;

    // Player's feet Y position
    const playerFeetY = playerPos.y - playerCurrentHeight;

    // Check if player is underneath the elevator platform moving down
    const playerIsUnderElevator =
        Math.abs(playerPos.x - platform.position.x) < (elevatorInstance.config.shaftWidth / 2 - 0.1) &&
        Math.abs(playerPos.z - platform.position.z) < (elevatorInstance.config.shaftDepth / 2 - 0.1) &&
        playerFeetY < currentPlatformY + 0.1 && // Player's feet are below the platform's top surface
        playerPos.y > nextPlatformY - 0.1;      // Player's head is above the platform's next bottom surface

    if (playerIsUnderElevator && elevatorInstance.direction < 0) { // Elevator moving down
        // Platform's bottom surface is at platform.position.y - 0.1
        const platformBottomY = nextPlatformY - 0.1;
        if (platformBottomY <= playerPos.y) { // Platform bottom hits player's head
            if (playerCurrentState === 'upright') {
                setPlayerState('crouching', 1.0, -0.7);
                if (typeof applyDamageFn === 'function') applyDamageFn(10); // Minor damage
                console.log("Player forced to crouch (under elevator)!");
            } else if (playerCurrentState === 'crouching') {
                setPlayerState('prone', 0.5, -0.5);
                if (typeof applyDamageFn === 'function') applyDamageFn(20); // More damage
                console.log("Player forced to prone (under elevator)!");
            } else if (playerCurrentState === 'prone') {
                if (typeof displayCrushBannerFn === 'function') displayCrushBannerFn();
                else console.warn("displayCrushBanner function not provided");
                gameStatusRef.isPlayerRespawning = true;
                // activeElevator = elevatorInstance; // Set by caller or getClosestElevator
            }
        }
    }

    // Check crushing by elevator's internal roof against the main shaftCeiling
    if (internalRoof && shaftCeiling && playerControlObject) {
        const playerIsOnThisInternalRoof =
            Math.abs(playerPos.x - internalRoof.position.x) < (elevatorInstance.config.shaftWidth / 2 - 0.1) &&
            Math.abs(playerPos.z - internalRoof.position.z) < (elevatorInstance.config.shaftDepth / 2 - 0.1) &&
            Math.abs(playerPos.y - (internalRoof.position.y + internalRoof.geometry.parameters.height / 2 + playerCurrentHeight)) < 0.2;


        if (playerIsOnThisInternalRoof && elevatorInstance.direction > 0) { // Moving up
            const playerEffectiveTopY = internalRoof.position.y + (internalRoof.geometry.parameters.height / 2) + playerCurrentHeight;
            const shaftCeilingBottomY = shaftCeiling.position.y - (shaftCeiling.geometry.parameters.height / 2);

            if (playerEffectiveTopY >= shaftCeilingBottomY - 0.1) {
                if (playerCurrentState === 'upright') {
                    setPlayerState('crouching', 1.0, -0.7);
                    if (typeof applyDamageFn === 'function') applyDamageFn(10);
                    console.log("Player forced to crouch (shaft ceiling)!");// elevator.js
import * as THREE from 'three';
import { SETTINGS } from './settings.js';
import { getControlsObject, getPlayerHeight, getPlayerState, setPlayerState, getPlayerVelocity, setPlayerOnGround } from './playerControls.js';

const elevators = [];
let activeElevator = null;

export function createElevator(config) {
    const floorDepth = SETTINGS.floorHeight - SETTINGS.wallHeight;

    const elevatorObj = {
        id: config.id,
        platform: null,
        roof: null, 
        chain: null,
        shaftCeiling: null, 
        shaftPit: null,     
        poles: [],
        minFloorIndex: config.minFloorIndex,
        maxFloorIndex: config.maxFloorIndex,
        currentY: (config.startFloorIndex * SETTINGS.floorHeight) - 0.1,
        targetY: (config.startFloorIndex * SETTINGS.floorHeight) - 0.1,
        isMoving: false,
        direction: 0,
        currentFloorIndexVal: config.startFloorIndex,
        config: config 
    };

    const platformGeo = new THREE.BoxGeometry(config.shaftWidth - 0.2, 0.2, config.shaftDepth - 0.2);
    elevatorObj.platform = new THREE.Mesh(platformGeo, config.platformMaterial);
    elevatorObj.platform.name = `ElevatorPlatform_${config.id}`;
    elevatorObj.platform.position.set(config.x, elevatorObj.currentY, config.z);
    elevatorObj.platform.castShadow = true;
    elevatorObj.platform.receiveShadow = true;
    config.scene.add(elevatorObj.platform);
    config.worldObjectsArr.push(elevatorObj.platform);
    elevatorObj.platform.userData.elevatorId = config.id;
    if (!elevatorObj.platform.geometry.boundingBox) {
        elevatorObj.platform.geometry.computeBoundingBox();
    }

    const elevatorInternalRoofThickness = 0.2;
    const internalRoofGeo = new THREE.BoxGeometry(config.shaftWidth - 0.2, elevatorInternalRoofThickness, config.shaftDepth - 0.2);
    elevatorObj.roof = new THREE.Mesh(internalRoofGeo, config.platformMaterial);
    elevatorObj.roof.name = `ElevatorInternalRoof_${config.id}`;
    elevatorObj.roof.position.set(config.x, elevatorObj.currentY + SETTINGS.wallHeight, config.z);
    elevatorObj.roof.castShadow = true;
    elevatorObj.roof.receiveShadow = true;
    config.scene.add(elevatorObj.roof);
    config.worldObjectsArr.push(elevatorObj.roof);
    if (!elevatorObj.roof.geometry.boundingBox) {
        elevatorObj.roof.geometry.computeBoundingBox();
    }
    elevatorObj.roof.userData.elevatorId = config.id;

    const elevatorLight = new THREE.PointLight(0xffffff, 0.8, 4); 
    elevatorLight.position.set(0, -elevatorInternalRoofThickness / 2 - 0.1, 0);
    elevatorObj.roof.add(elevatorLight);

    const poleDimension = 0.1;
    const poleHeight = SETTINGS.wallHeight;
    const poleGeo = new THREE.BoxGeometry(poleDimension, poleHeight, poleDimension);
    const platformInnerWidth = config.shaftWidth - 0.2;
    const platformInnerDepth = config.shaftDepth - 0.2;

    const polePositions = [
        { x: -platformInnerWidth / 2 + poleDimension / 2, z: -platformInnerDepth / 2 + poleDimension / 2 },
        { x:  platformInnerWidth / 2 - poleDimension / 2, z: -platformInnerDepth / 2 + poleDimension / 2 },
        { x: -platformInnerWidth / 2 + poleDimension / 2, z:  platformInnerDepth / 2 - poleDimension / 2 },
        { x:  platformInnerWidth / 2 - poleDimension / 2, z:  platformInnerDepth / 2 - poleDimension / 2 }
    ];
    polePositions.forEach((pos, index) => {
        const pole = new THREE.Mesh(poleGeo, config.platformMaterial.clone()); 
        pole.name = `ElevatorPole_${config.id}_${index}`;
        pole.position.set(pos.x, 0.1 + poleHeight / 2, pos.z); 
        pole.castShadow = true; pole.receiveShadow = true;
        pole.userData.elevatorId = config.id;
        elevatorObj.platform.add(pole); 
        elevatorObj.poles.push(pole);
    });

    const shaftCeilingY = (config.maxFloorIndex + 1) * SETTINGS.floorHeight;
    const shaftCeilingGeo = new THREE.BoxGeometry(config.shaftWidth, floorDepth - 0.02, config.shaftDepth);
    elevatorObj.shaftCeiling = new THREE.Mesh(shaftCeilingGeo, config.shaftMaterial);
    elevatorObj.shaftCeiling.name = `ElevatorShaftCeiling_${config.id}`;
    elevatorObj.shaftCeiling.position.set(config.x, shaftCeilingY - floorDepth / 2, config.z);
    elevatorObj.shaftCeiling.castShadow = true; elevatorObj.shaftCeiling.receiveShadow = true;
    config.scene.add(elevatorObj.shaftCeiling);
    config.worldObjectsArr.push(elevatorObj.shaftCeiling);
    if (!elevatorObj.shaftCeiling.geometry.boundingBox) {
        elevatorObj.shaftCeiling.geometry.computeBoundingBox();
    }

    const pitThickness = SETTINGS.floorHeight;
    const pitTopSurfaceY = (config.minFloorIndex * SETTINGS.floorHeight) - floorDepth;
    const pitCenterY = pitTopSurfaceY - pitThickness / 2;
    const pitGeo = new THREE.BoxGeometry(config.shaftWidth, pitThickness, config.shaftDepth);
    elevatorObj.shaftPit = new THREE.Mesh(pitGeo, config.shaftMaterial);
    elevatorObj.shaftPit.name = `ElevatorShaftPit_${config.id}`;
    elevatorObj.shaftPit.position.set(config.x, pitCenterY, config.z);
    elevatorObj.shaftPit.receiveShadow = true;
    config.scene.add(elevatorObj.shaftPit);
    config.worldObjectsArr.push(elevatorObj.shaftPit);
    if (!elevatorObj.shaftPit.geometry.boundingBox) {
        elevatorObj.shaftPit.geometry.computeBoundingBox();
    }

    const chain = createDynamicChainMesh(elevatorObj, config.platformMaterial);
    elevatorObj.chain = chain;
    chain.userData.elevatorId = config.id;
    elevatorObj.platform.add(chain); 

    const piston = createElevatorPistonMesh(elevatorObj, config.platformMaterial);
    piston.userData.elevatorId = config.id;
    elevatorObj.platform.add(piston); 
    // config.worldObjectsArr.push(piston); // Not typically needed for collision if platform handles it

    elevators.push(elevatorObj);
    if (!activeElevator) {
        activeElevator = elevatorObj;
    }
    return elevatorObj;
}

function createElevatorPistonMesh(elevatorObj, material) {
    const bottomShaftThickness = 0.2;
    const totalTravel = (elevatorObj.maxFloorIndex - elevatorObj.minFloorIndex) * SETTINGS.floorHeight;
    const bottomShaftActualHeight = totalTravel + SETTINGS.floorHeight;

    const bottomShaftGeo = new THREE.BoxGeometry(bottomShaftThickness, bottomShaftActualHeight, bottomShaftThickness);
    const bottomShaft = new THREE.Mesh(bottomShaftGeo, material);
    bottomShaft.name = `ElevatorBottomPistonShaft_${elevatorObj.id}`;
    bottomShaft.position.set(0, -0.1 - (bottomShaftActualHeight / 2), 0); 
    bottomShaft.castShadow = true;
    bottomShaft.receiveShadow = true;
    if (!bottomShaft.geometry.boundingBox) {
        bottomShaft.geometry.computeBoundingBox();
    }
    return bottomShaft;
}

function createDynamicChainMesh(elevatorObj, material) {
    const chainThickness = 0.1;
    const internalRoofThickness = elevatorObj.roof.geometry.parameters.height;

    const internalRoofTopLocalY = (0.1 + SETTINGS.wallHeight - internalRoofThickness / 2) + internalRoofThickness;
    const minPlatformY = (elevatorObj.minFloorIndex * SETTINGS.floorHeight) - 0.1;
    const minInternalRoofTopWorldY = minPlatformY + internalRoofTopLocalY;
    const shaftCeilingBottomWorldY = elevatorObj.shaftCeiling.position.y - elevatorObj.shaftCeiling.geometry.parameters.height / 2;
    const initialGeomHeight = Math.max(0.01, shaftCeilingBottomWorldY - minInternalRoofTopWorldY);

    const chainGeometry = new THREE.BoxGeometry(chainThickness, initialGeomHeight, chainThickness);
    const chainMesh = new THREE.Mesh(chainGeometry, material);
    chainMesh.name = `ElevatorChain_${elevatorObj.id}`;
    chainMesh.position.set(0, internalRoofTopLocalY + initialGeomHeight / 2, 0); 
    chainMesh.castShadow = true;
    chainMesh.receiveShadow = true;
    chainMesh.userData.initialGeomHeight = initialGeomHeight;
    return chainMesh;
}

function updateChainLength(elevatorInstance) {
    const chain = elevatorInstance.chain;
    const internalRoof = elevatorInstance.roof;
    const shaftCeiling = elevatorInstance.shaftCeiling;

    if (chain && internalRoof && shaftCeiling && chain.userData.initialGeomHeight) {
        const initialGeomHeight = chain.userData.initialGeomHeight;
        const internalRoofThickness = internalRoof.geometry.parameters.height;

        const internalRoofTopWorldY = internalRoof.position.y + internalRoofThickness / 2;
        const shaftCeilingBottomWorldY = shaftCeiling.position.y - shaftCeiling.geometry.parameters.height / 2;
        const currentVisibleChainLength = Math.max(0.01, shaftCeilingBottomWorldY - internalRoofTopWorldY);

        chain.scale.y = currentVisibleChainLength / initialGeomHeight;

        const internalRoofTopLocalY = (0.1 + SETTINGS.wallHeight - internalRoofThickness / 2) + internalRoofThickness;
        chain.position.y = internalRoofTopLocalY + currentVisibleChainLength / 2;
    }
}

export function getClosestElevator() {
    if (elevators.length === 0) return null;
    if (elevators.length === 1) return elevators[0];

    const playerControlObject = getControlsObject();
    if (!playerControlObject) return elevators[0]; 

    const playerPos = playerControlObject.position;
    let closestDistanceSq = Infinity;
    let closestElev = elevators[0];

    for (const elev of elevators) {
        const distanceSq = playerPos.distanceToSquared(elev.platform.position);
        if (distanceSq < closestDistanceSq) {
            closestDistanceSq = distanceSq;
            closestElev = elev;
        }
    }
    return closestElev;
}

export function callElevator(direction) {
    const currentActiveElevator = getClosestElevator();
    if (!currentActiveElevator) return;
    activeElevator = currentActiveElevator; 

    let targetFloor = activeElevator.currentFloorIndexVal + direction;
    targetFloor = Math.max(activeElevator.minFloorIndex, Math.min(activeElevator.maxFloorIndex, targetFloor));
    const newTargetY = (targetFloor * SETTINGS.floorHeight) - 0.1;

    if (newTargetY !== activeElevator.targetY || !activeElevator.isMoving) {
        activeElevator.targetY = newTargetY;
        activeElevator.direction = Math.sign(activeElevator.targetY - activeElevator.platform.position.y);
        if (activeElevator.platform.position.y.toFixed(2) !== newTargetY.toFixed(2)) {
             activeElevator.isMoving = true;
        }
        console.log(`Elevator ${activeElevator.id} called to floor ${targetFloor}. Moving ${activeElevator.direction > 0 ? 'UP' : (activeElevator.direction < 0 ? 'DOWN' : 'STATIONARY')}.`);
    }
}

export function callSpecificElevatorToFloor(elevatorInstance, targetFloorIndex) {
    if (!elevatorInstance) return;

    const effectiveTargetFloor = Math.max(elevatorInstance.minFloorIndex, Math.min(elevatorInstance.maxFloorIndex, targetFloorIndex));
    const newTargetY = (effectiveTargetFloor * SETTINGS.floorHeight) - 0.1;

    if (newTargetY !== elevatorInstance.targetY || !elevatorInstance.isMoving) {
        elevatorInstance.targetY = newTargetY;
        elevatorInstance.direction = Math.sign(elevatorInstance.targetY - elevatorInstance.platform.position.y);
        if (elevatorInstance.platform.position.y.toFixed(2) !== newTargetY.toFixed(2)) {
            elevatorInstance.isMoving = true;
        }
        console.log(`Elevator ${elevatorInstance.id} specifically called to floor ${effectiveTargetFloor}.`);
        activeElevator = elevatorInstance; 
    }
}

/**
 * Updates the state and position of all elevators.
 * @param {number} deltaTime - The time elapsed since the last frame.
 * @param {Function} displayCrushBannerFunc - Function to display the crush banner (from ui.js via main.js).
 * @param {Function} respawnPlayerFunc - Function to respawn the player (from gameLogic.js via main.js).
 * @param {Function} applyDamageFunc - Function to apply damage to the player (from gameLogic.js via main.js).
 * @param {object} gameStatus - Shared game status object from main.js.
 */
export function updateElevators(deltaTime, displayCrushBannerFunc, respawnPlayerFunc, applyDamageFunc, gameStatus) {
    const playerControlObject = getControlsObject(); // From playerControls.js
    const currentPlayerHeight = getPlayerHeight ? getPlayerHeight() : 1.7; // From playerControls.js

    elevators.forEach(elev => {
        if (!elev.isMoving) return;

        const targetY = elev.targetY;
        const currentPlatformY = elev.platform.position.y;
        const moveAmount = SETTINGS.elevatorSpeed * deltaTime * elev.direction;
        let nextPlatformY = currentPlatformY + moveAmount;
        let arrived = false;

        if (elev.direction > 0 && nextPlatformY >= targetY) {
            nextPlatformY = targetY; arrived = true;
        } else if (elev.direction < 0 && nextPlatformY <= targetY) {
            nextPlatformY = targetY; arrived = true;
        }

        elev.platform.position.y = nextPlatformY;
        elev.currentY = nextPlatformY;
        if (elev.roof) {
            elev.roof.position.y = nextPlatformY + SETTINGS.wallHeight;
            updateChainLength(elev);
        }

        elev.platform.updateMatrixWorld(true);
        if (elev.roof) elev.roof.updateMatrixWorld(true);

        if (playerControlObject) {
            handlePlayerCrush(elev, currentPlatformY, nextPlatformY, displayCrushBannerFunc, applyDamageFunc, gameStatus);

            const playerPos = playerControlObject.position;
            const playerFeetY = playerPos.y - currentPlayerHeight;
            const playerHeadY = playerPos.y;

            const isOnPlatform = 
                Math.abs(playerPos.x - elev.platform.position.x) < (elev.config.shaftWidth / 2 - 0.15) && // Slightly smaller tolerance
                Math.abs(playerPos.z - elev.platform.position.z) < (elev.config.shaftDepth / 2 - 0.15) &&
                playerFeetY >= elev.platform.position.y + 0.1 - 0.2 && // Feet on or slightly above platform top (within 0.2 tolerance)
                playerFeetY < elev.platform.position.y + 0.1 + 0.3;   // Feet not too far above platform top

            const isOnInternalRoof = elev.roof &&
                Math.abs(playerPos.x - elev.roof.position.x) < (elev.config.shaftWidth / 2 - 0.15) &&
                Math.abs(playerPos.z - elev.roof.position.z) < (elev.config.shaftDepth / 2 - 0.15) &&
                playerFeetY >= elev.roof.position.y + (elev.roof.geometry.parameters.height / 2) - 0.2 &&
                playerFeetY < elev.roof.position.y + (elev.roof.geometry.parameters.height / 2) + 0.3;


            if (isOnPlatform) {
                playerPos.y = elev.platform.position.y + 0.1 + currentPlayerHeight; 
                if(setPlayerOnGround) setPlayerOnGround(true);
                const playerVel = getPlayerVelocity ? getPlayerVelocity() : null;
                if(playerVel) playerVel.y = 0; 
            } else if (isOnInternalRoof) {
                playerPos.y = elev.roof.position.y + (elev.roof.geometry.parameters.height / 2) + currentPlayerHeight;
                if(setPlayerOnGround) setPlayerOnGround(true);
                const playerVel = getPlayerVelocity ? getPlayerVelocity() : null;
                if(playerVel) playerVel.y = 0;
            }
        }

        if (arrived) {
            elev.isMoving = false;
            elev.currentFloorIndexVal = Math.round((targetY + 0.1) / SETTINGS.floorHeight);
            console.log(`Elevator ${elev.id} arrived at floor ${elev.currentFloorIndexVal}`);

            if (playerControlObject && isOnPlatform) { // Check isOnPlatform from closure
                const playerPos = playerControlObject.position;
                const stillOnPlatformAfterArrival = 
                    Math.abs(playerPos.x - elev.platform.position.x) < (elev.config.shaftWidth / 2 - 0.1) &&
                    Math.abs(playerPos.z - elev.platform.position.z) < (elev.config.shaftDepth / 2 - 0.1) &&
                    Math.abs(playerPos.y - (elev.platform.position.y + 0.1 + currentPlayerHeight)) < 0.3;
                
                if (stillOnPlatformAfterArrival) {
                    const playerVel = getPlayerVelocity ? getPlayerVelocity() : null;
                    if(playerVel) playerVel.y = 2.0; 
                    if(setPlayerOnGround) setPlayerOnGround(false);
                }
            }

            if (gameStatus.isPlayerRespawning && elev === activeElevator) {
                if (typeof respawnPlayerFunc === 'function') respawnPlayerFunc();
                else console.warn("respawnPlayer function not provided to updateElevators");
            }
        }
    });
}


function handlePlayerCrush(elevatorInstance, currentPlatformY, nextPlatformY, displayCrushBannerFunc, applyDamageFunc, gameStatusRef) {
    const playerControlObject = getControlsObject();
    if (!playerControlObject) return;

    const playerPos = playerControlObject.position;
    const playerCurrentHeight = getPlayerHeight ? getPlayerHeight() : 1.7;
    let playerCurrentState = getPlayerState ? getPlayerState() : 'upright';

    const platform = elevatorInstance.platform;
    const internalRoof = elevatorInstance.roof;
    const shaftCeiling = elevatorInstance.shaftCeiling;

    const playerFeetY = playerPos.y - playerCurrentHeight;
    const playerHeadY = playerPos.y;

    // Check if player is underneath the elevator platform moving down
    const playerIsUnderElevator =
        Math.abs(playerPos.x - platform.position.x) < (elevatorInstance.config.shaftWidth / 2 - 0.1) &&
        Math.abs(playerPos.z - platform.position.z) < (elevatorInstance.config.shaftDepth / 2 - 0.1) &&
        playerFeetY < currentPlatformY + 0.1 && 
        playerHeadY > nextPlatformY - 0.1;      

    if (playerIsUnderElevator && elevatorInstance.direction < 0) { 
        const platformBottomActualY = nextPlatformY - 0.1; // Bottom surface of the platform
        if (platformBottomActualY <= playerHeadY) { 
            if (playerCurrentState === 'upright') {
                if(setPlayerState) setPlayerState('crouching', 1.0, -0.7);
                if (applyDamageFunc) applyDamageFunc({ target: 'player', amount: 10 });
                console.log("Player forced to crouch (under elevator)!");
            } else if (playerCurrentState === 'crouching') {
                if(setPlayerState) setPlayerState('prone', 0.5, -0.5);
                if (applyDamageFunc) applyDamageFunc({ target: 'player', amount: 20 });
                console.log("Player forced to prone (under elevator)!");
            } else if (playerCurrentState === 'prone') {
                if (displayCrushBannerFunc) displayCrushBannerFunc();
                if (applyDamageFunc) applyDamageFunc({ target: 'player', amount: 100 }); // Lethal
                gameStatusRef.isPlayerRespawning = true; 
            }
        }
    }

    if (internalRoof && shaftCeiling && playerControlObject) {
        const playerIsOnThisInternalRoof =
            Math.abs(playerPos.x - internalRoof.position.x) < (elevatorInstance.config.shaftWidth / 2 - 0.1) &&
            Math.abs(playerPos.z - internalRoof.position.z) < (elevatorInstance.config.shaftDepth / 2 - 0.1) &&
            Math.abs(playerPos.y - (internalRoof.position.y + internalRoof.geometry.parameters.height / 2 + playerCurrentHeight)) < 0.3;


        if (playerIsOnThisInternalRoof && elevatorInstance.direction > 0) { 
            const playerEffectiveTopY = internalRoof.position.y + (internalRoof.geometry.parameters.height / 2) + playerCurrentHeight;
            const shaftCeilingBottomY = shaftCeiling.position.y - (shaftCeiling.geometry.parameters.height / 2);

            if (playerEffectiveTopY >= shaftCeilingBottomY - 0.1) {
                if (playerCurrentState === 'upright') {
                    if(setPlayerState) setPlayerState('crouching', 1.0, -0.7);
                    if (applyDamageFunc) applyDamageFunc({ target: 'player', amount: 10 });
                    console.log("Player forced to crouch (shaft ceiling)!");
                } else if (playerCurrentState === 'crouching') {
                    if(setPlayerState) setPlayerState('prone', 0.5, -0.5);
                    if (applyDamageFunc) applyDamageFunc({ target: 'player', amount: 20 });
                    console.log("Player forced to prone (shaft ceiling)!");
                } else if (playerCurrentState === 'prone') {
                    if (displayCrushBannerFunc) displayCrushBannerFunc();
                    if (applyDamageFunc) applyDamageFunc({ target: 'player', amount: 100 }); // Lethal
                    gameStatusRef.isPlayerRespawning = true;
                }
            }
        }
    }
}

export {
    elevators,
    activeElevator, 
};
