// File: player.js
import * as THREE from 'three';

export class Player {
    constructor(scene) {
        this.scene = scene;
        this.geometry = new THREE.BoxGeometry(1, 2, 1);
        this.material = new THREE.MeshStandardMaterial({ color: 0x00ff00 });
        this.mesh = new THREE.Mesh(this.geometry, this.material);
        this.mesh.position.set(0, 1, 0);
        scene.add(this.mesh);
        this.velocity = new THREE.Vector3();
        this.speed = 5;
        this.initControls();
    }

    initControls() {
        this.keys = {};
        window.addEventListener('keydown', (e) => this.keys[e.code] = true);
        window.addEventListener('keyup', (e) => this.keys[e.code] = false);
    }

    update(delta) {
        this.velocity.set(0, 0, 0);
        if (this.keys['KeyW']) this.velocity.z -= this.speed * delta;
        if (this.keys['KeyS']) this.velocity.z += this.speed * delta;
        if (this.keys['KeyA']) this.velocity.x -= this.speed * delta;
        if (this.keys['KeyD']) this.velocity.x += this.speed * delta;

        this.mesh.position.add(this.velocity);
    }
}
