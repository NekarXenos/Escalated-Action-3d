// File: floorManager.js
import * as THREE from 'three';

export class FloorManager {
    constructor(scene) {
        this.scene = scene;
        this.floors = [];
        this.createFloors();
    }

    createFloors() {
        const roomSize = 10;
        for (let floorIndex = 0; floorIndex < 30; floorIndex++) {
            const floorGroup = new THREE.Group();
            const yOffset = floorIndex * 5;

            // Center hallway
            const hallway = new THREE.Mesh(
                new THREE.BoxGeometry(roomSize * 2, 0.2, roomSize * 3),
                new THREE.MeshStandardMaterial({ color: 0x888888 })
            );
            hallway.position.y = yOffset;
            floorGroup.add(hallway);

            // Rooms left and right
            for (let side = -1; side <= 1; side += 2) {
                for (let i = 0; i < 3; i++) {
                    const room = new THREE.Mesh(
                        new THREE.BoxGeometry(roomSize, 3, roomSize),
                        new THREE.MeshStandardMaterial({ color: 0xaaaaaa })
                    );
                    room.position.set(side * roomSize * 1.5, yOffset + 1.5, (i - 1) * roomSize);
                    floorGroup.add(room);
                }
            }

            this.floors.push(floorGroup);
            this.scene.add(floorGroup);
        }
    }
}
