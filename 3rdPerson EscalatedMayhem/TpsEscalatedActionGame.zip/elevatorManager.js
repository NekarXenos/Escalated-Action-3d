{\rtf1}// File: elevatorManager.js
import * as THREE from 'three';

export class ElevatorManager {
    constructor(scene) {
        this.scene = scene;
        this.elevators = [];
        this.createElevators();
    }

    createElevators() {
        const elevatorWidth = 2;
        const elevatorHeight = 3;
        const elevatorDepth = 2;
        const gap = 4;

        for (let i = 0; i < 6; i++) {
            const elevator = new THREE.Mesh(
                new THREE.BoxGeometry(elevatorWidth, elevatorHeight, elevatorDepth),
                new THREE.MeshStandardMaterial({ color: 0xffcc00 })
            );
            elevator.position.set((i - 2.5) * gap, 1.5, 0);
            this.scene.add(elevator);
            this.elevators.push({ mesh: elevator, targetFloor: 0 });
        }
    }

    update(delta) {
        for (let e of this.elevators) {
            const targetY = e.targetFloor * 5 + 1.5;
            e.mesh.position.y += (targetY - e.mesh.position.y) * delta;
        }
    }

    moveElevatorToFloor(index, floor) {
        if (this.elevators[index]) {
            this.elevators[index].targetFloor = floor;
        }
    }
}
