// File: doorManager.js
import * as THREE from 'three';

export class DoorManager {
    constructor(scene) {
        this.scene = scene;
        this.doors = [];
    }

    createDoor(position) {
        const doorWidth = 1;
        const doorHeight = 3;
        const doorDepth = 0.2;

        const door = new THREE.Mesh(
            new THREE.BoxGeometry(doorWidth, doorHeight, doorDepth),
            new THREE.MeshStandardMaterial({ color: 0x552200 })
        );
        door.position.copy(position);
        door.userData.open = false;

        this.scene.add(door);
        this.doors.push(door);
        return door;
    }

    toggleDoor(door) {
        door.userData.open = !door.userData.open;
        door.visible = !door.userData.open;
    }

    update(player) {
        const playerBox = new THREE.Box3().setFromObject(player.mesh);

        for (let door of this.doors) {
            const doorBox = new THREE.Box3().setFromObject(door);
            if (playerBox.intersectsBox(doorBox) && door.userData.open === false) {
                this.toggleDoor(door);
            }
        }
    }
}
