// File: escalatorManager.js
import * as THREE from 'three';

export class EscalatorManager {
    constructor(scene) {
        this.scene = scene;
        this.escalators = [];
        this.createEscalators();
    }

    createEscalators() {
        const floorCount = 30;
        const escalatorWidth = 2;
        const escalatorHeight = 5;
        const escalatorDepth = 2;
        const spacing = 10;

        for (let f = 0; f < floorCount - 1; f++) {
            const yOffset = f * 5;
            const directions = ['up', 'down'];

            directions.forEach((dir, idx) => {
                const escalator = new THREE.Mesh(
                    new THREE.BoxGeometry(escalatorWidth, escalatorHeight, escalatorDepth),
                    new THREE.MeshStandardMaterial({ color: dir === 'up' ? 0x0000ff : 0xff0000 })
                );
                const zOffset = (idx === 0 ? -1 : 1) * (spacing * 1.5);
                escalator.position.set(15, yOffset + escalatorHeight / 2, zOffset);
                escalator.rotation.z = Math.PI / 10 * (dir === 'up' ? -1 : 1);

                this.scene.add(escalator);
                this.escalators.push({ mesh: escalator, direction: dir, fromFloor: f });
            });
        }
    }

    update(player, delta) {
        const playerBox = new THREE.Box3().setFromObject(player.mesh);

        for (let e of this.escalators) {
            const escalatorBox = new THREE.Box3().setFromObject(e.mesh);
            if (playerBox.intersectsBox(escalatorBox)) {
                const speed = 2;
                if (e.direction === 'up') {
                    player.mesh.position.y += speed * delta;
                } else {
                    player.mesh.position.y -= speed * delta;
                }
            }
        }
    }
}
