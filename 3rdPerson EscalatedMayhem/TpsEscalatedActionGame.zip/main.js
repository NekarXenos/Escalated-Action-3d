// File: main.js
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { Player } from './player.js';
import { FloorManager } from './floorManager.js';
import { ElevatorManager } from './elevatorManager.js';
import { LightingManager } from './lightingManager.js';
import { EscalatorManager } from './escalatorManager.js';
import { DoorManager } from './doorManager.js';
import { InteractionManager } from './interactionManager.js';

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
const clock = new THREE.Clock();

const player = new Player(scene);
const floorManager = new FloorManager(scene);
const elevatorManager = new ElevatorManager(scene);
const lightingManager = new LightingManager(scene);
const escalatorManager = new EscalatorManager(scene);
const doorManager = new DoorManager(scene);
const interactionManager = new InteractionManager(doorManager, camera, player);

// Example: add a few doors
const exampleDoor1 = doorManager.createDoor(new THREE.Vector3(-15, 1.5, -10));
const exampleDoor2 = doorManager.createDoor(new THREE.Vector3(15, 1.5, 10));

camera.position.set(0, 20, 50);

function animate() {
    requestAnimationFrame(animate);
    const delta = clock.getDelta();
    player.update(delta);
    elevatorManager.update(delta);
    escalatorManager.update(player, delta);
    renderer.render(scene, camera);
}

animate();
