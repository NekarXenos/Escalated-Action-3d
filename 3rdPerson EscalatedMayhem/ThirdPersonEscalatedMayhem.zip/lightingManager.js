// File: lightingManager.js
import * as THREE from 'three';

export class LightingManager {
    constructor(scene) {
        this.scene = scene;
        this.lights = [];
        this.createLights();
    }

    createLights() {
        const floorCount = 30;
        for (let f = 0; f < floorCount; f++) {
            const yOffset = f * 5 + 4.5;
            for (let i = -1; i <= 1; i++) {
                const light = new THREE.PointLight(0xffffff, 1, 20);
                light.position.set(0, yOffset, i * 10);
                this.scene.add(light);
                this.lights.push({ light, active: true });
            }
        }
    }

    shootLight(index) {
        if (this.lights[index] && this.lights[index].active) {
            this.lights[index].light.intensity = 0;
            this.lights[index].active = false;
            // Add logic to affect enemies later
        }
    }
}
