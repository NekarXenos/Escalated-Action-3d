// File: doorPlacement.js
import * as THREE from 'three';

export function placeDoors(doorManager) {
    const floors = 30;
    const roomCount = 3;
    const roomSpacing = 10;

    for (let floor = 0; floor < floors; floor++) {
        const y = floor * 5 + 1.5;

        for (let i = 0; i < roomCount; i++) {
            const zOffset = (i - 1) * roomSpacing;

            // Left wing
            const leftDoorPos = new THREE.Vector3(-15, y, zOffset);
            doorManager.createDoor(leftDoorPos);

            // Right wing
            const rightDoorPos = new THREE.Vector3(15, y, zOffset);
            doorManager.createDoor(rightDoorPos);
        }
    }
}
