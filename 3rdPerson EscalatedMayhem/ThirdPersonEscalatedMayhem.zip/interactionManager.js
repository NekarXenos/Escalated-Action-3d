// File: interactionManager.js
export class InteractionManager {
    constructor(doorManager, camera, player) {
        this.doorManager = doorManager;
        this.camera = camera;
        this.player = player;
        this.init();
    }

    init() {
        window.addEventListener('keydown', (e) => {
            if (e.code === 'KeyE') {
                this.tryInteract();
            }
        });
    }

    tryInteract() {
        const playerPos = this.player.mesh.position;

        for (let door of this.doorManager.doors) {
            const dist = door.position.distanceTo(playerPos);
            if (dist < 2.5) {
                this.doorManager.toggleDoor(door);
                break;
            }
        }
    }
}
